package Chandri;
import java.util.Scanner;

public class Chandrayan{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String in;
        char dir = 'N';
        int x = 0, y = 0, z = 0;
        
        System.out.print("Enter initial direction (N/E/U/D): ");
        dir = scanner.next().charAt(0);
        
        System.out.print("Enter command sequence: ");
        in = scanner.next();
        
        System.out.print("Enter initial position (x y z): ");
        x = scanner.nextInt();
        y = scanner.nextInt();
        z = scanner.nextInt();
        
        for (int i = 0; i < in.length(); i++) {
            char command = in.charAt(i);
            switch (command) {
                case 'f':
                    y++;
                    break;
                case 'b':
                    z--;
                    break;
                case 'l':
                    dir = 'N';
                    break;
                case 'r':
                    dir = 'E';
                    break;
                case 'u':
                    dir = 'U';
                    break;
                case 'd':
                    dir = 'D';
                    break;
                default:
                    // Handle invalid commands if needed
                    break;
            }
        }
        
        System.out.println("Final Direction : " + dir);
        System.out.println("Final Position : " + x + " " + y + " " + z);
        
        scanner.close();
    }
}
